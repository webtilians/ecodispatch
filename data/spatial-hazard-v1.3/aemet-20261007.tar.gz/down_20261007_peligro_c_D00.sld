<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.0.0"
    xmlns="http://www.opengis.net/sld"
    xmlns:ogc="http://www.opengis.net/ogc"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="
        http://www.opengis.net/sld
        http://schemas.opengis.net/sld/1.0.0/StyledLayerDescriptor.xsd">

  <NamedLayer>
    <Name>Danger level Style</Name>

    <UserStyle>
      <Title>Estilo de peligro de incendios</Title>

      <FeatureTypeStyle>
        <Rule>
          <RasterSymbolizer>
            <Opacity>1.0</Opacity>

            <ColorMap type="values">
              <ColorMapEntry color="#000000" quantity="0" opacity="0.0" label="Sin Datos"/>
              <ColorMapEntry color="#4B96E3" quantity="1" label="Muy bajo"/>
              <ColorMapEntry color="#51D1F6" quantity="2" label="Bajo"/>
              <ColorMapEntry color="#57E520" quantity="3" label="Moderado"/>
              <ColorMapEntry color="#F9FB2F" quantity="4" label="Alto"/>
              <ColorMapEntry color="#EF8504" quantity="5" label="Muy alto"/>
              <ColorMapEntry color="#F52300" quantity="6" label="Extremo"/>
            </ColorMap>

          </RasterSymbolizer>
        </Rule>
      </FeatureTypeStyle>

    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>
