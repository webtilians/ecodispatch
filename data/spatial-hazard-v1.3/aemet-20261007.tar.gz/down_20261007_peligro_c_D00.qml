<!DOCTYPE qgis PUBLIC 'http://mrcc.com' 'SYSTEM'>
<qgis version="3.28.0" hasScaleBasedVisibilityFlag="0" minScale="1e+08" maxScale="0">
  <pipe-data-defined-properties>
    <Option type="Map"/>
  </pipe-data-defined-properties>
  <pipe>
    <provider>
      <resampling maxOversampling="2" zoomedOutResamplingMethod="nearestNeighbour" zoomedInResamplingMethod="nearestNeighbour" enabled="false"/>
    </provider>
    <rasterrenderer type="paletted" opacity="1" alphaBand="-1" band="1">
      
      <!-- Valor 0 (NaN) transparente -->
      <rasterTransparency>
        <singleValuePixelList>
          <pixelListEntry pixelValue="0" percentTransparent="100"/>
        </singleValuePixelList>
      </rasterTransparency>

      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>

      <colorPalette>
        <!-- Valor 1: 75,150,227 -->
        <paletteEntry color="#4b96e3" value="1" alpha="255" label="Muy bajo"/>
        
        <!-- Valor 2: 81,209,246 -->
        <paletteEntry color="#51d1f6" value="2" alpha="255" label="Bajo"/>
        
        <!-- Valor 3: 87,229,32 -->
        <paletteEntry color="#57e520" value="3" alpha="255" label="Moderado"/>
        
        <!-- Valor 4: 249,251,47 -->
        <paletteEntry color="#f9fb2f" value="4" alpha="255" label="Alto"/>
        
        <!-- Valor 5: 239,133,4 -->
        <paletteEntry color="#ef8504" value="5" alpha="255" label="Muy alto"/>
        
        <!-- Valor 6: 245,35,0 -->
        <paletteEntry color="#f52300" value="6" alpha="255" label="Extremo"/>
      </colorPalette>

    </rasterrenderer>

    <brightnesscontrast brightness="0" contrast="0"/>
    <huesaturation colorizeGreen="128" colorizeOn="0" colorizeStrength="100" saturation="0" colorizeRed="255" grayscaleMode="0" colorizeBlue="128" invertColors="0"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
